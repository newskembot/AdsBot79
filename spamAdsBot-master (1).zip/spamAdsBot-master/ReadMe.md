# SpamADsBot

[deploy to heroku](https://dashboard.heroku.com/new?template=https://github.com/xditya/spamAdsBot)